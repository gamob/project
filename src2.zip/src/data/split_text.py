"""
split_text.py — Semantic chunking using bge-m3 embeddings.

Instead of cutting at a fixed character count, this splits text by detecting
where the topic actually shifts — measured as a drop in cosine similarity
between adjacent sentence embeddings.

Falls back to RecursiveCharacterTextSplitter for:
  - Very short documents (< 3 sentences)
  - Structured/tabular files (CSV, XLSX) where row = natural unit
"""

import logging
import re
import os
import numpy as np
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from ..core.config_service import ConfigManager

logger = logging.getLogger(__name__)

# ── Offline mode ──────────────────────────────────────────────────────────────
os.environ["HF_HUB_OFFLINE"]      = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"

# ── Semantic chunking settings ────────────────────────────────────────────────
# How far below the local average similarity a boundary must drop to trigger a split.
# Lower = more cuts (smaller chunks). Higher = fewer cuts (larger chunks).
BREAKPOINT_THRESHOLD = 0.15   # fraction below rolling average

# Hard limits — even semantic chunks won't exceed / go below these
MAX_CHUNK_CHARS = 1200
MIN_CHUNK_CHARS = 80

# Files where semantic chunking doesn't apply — use fixed splitting instead
FIXED_SPLIT_TYPES = {".csv", ".xlsx"}

# ── Fallback profiles (for short docs and fixed-split types) ──────────────────
CHUNK_PROFILES = {
    ".pdf":  {"chunk_size": 1000, "chunk_overlap": 150},
    ".docx": {"chunk_size": 1000, "chunk_overlap": 150},
    ".txt":  {"chunk_size": 800,  "chunk_overlap": 100},
    ".md":   {"chunk_size": 800,  "chunk_overlap": 100},
    ".pptx": {"chunk_size": 600,  "chunk_overlap": 80},
    ".xlsx": {"chunk_size": 400,  "chunk_overlap": 50},
    ".csv":  {"chunk_size": 400,  "chunk_overlap": 50},
}
DEFAULT_PROFILE = {"chunk_size": 800, "chunk_overlap": 100}

# ── Lazy embedding model ──────────────────────────────────────────────────────
_embed_model = None

def _get_embed_model():
    """Load bge-m3 once and reuse — same model used by FAISS."""
    global _embed_model
    if _embed_model is None:
        from sentence_transformers import SentenceTransformer
        model_path = os.path.join(
            ConfigManager.PROJECT_ROOT,
            ConfigManager.get("MODEL_PATH", "model/bge-m3")
        )
        logger.info(f"🔤 Loading embedding model for semantic chunking: {model_path}")
        _embed_model = SentenceTransformer(model_path, device="cpu")
    return _embed_model


# ── Sentence splitting ────────────────────────────────────────────────────────
_SENT_END = re.compile(r"(?<=[.!?。！？])\s+")

def _split_sentences(text: str) -> list[str]:
    """Split text into sentences, keeping each non-empty."""
    raw = _SENT_END.split(text.strip())
    return [s.strip() for s in raw if len(s.strip()) >= 20]


# ── Cosine similarity ─────────────────────────────────────────────────────────
def _cosine(a: np.ndarray, b: np.ndarray) -> float:
    denom = np.linalg.norm(a) * np.linalg.norm(b)
    return float(np.dot(a, b) / denom) if denom > 0 else 0.0


# ── Core semantic chunker ─────────────────────────────────────────────────────
def _semantic_split(text: str) -> list[str]:
    """
    Split text into semantically coherent chunks.

    Algorithm:
    1. Split into sentences.
    2. Embed all sentences with bge-m3 (batch — fast).
    3. Compute cosine similarity between each adjacent pair.
    4. Find valleys (drops below rolling average - threshold) → breakpoints.
    5. Merge sentence groups between breakpoints into chunks.
    6. If any chunk exceeds MAX_CHUNK_CHARS, split it further with the fallback splitter.
    """
    sentences = _split_sentences(text)
    if len(sentences) < 3:
        return [text]  # too short for semantic analysis

    model = _get_embed_model()
    embeddings = model.encode(sentences, batch_size=32, show_progress_bar=False,
                              normalize_embeddings=True)

    # Pairwise similarities between adjacent sentences
    similarities = [_cosine(embeddings[i], embeddings[i + 1])
                    for i in range(len(embeddings) - 1)]

    # Rolling average similarity (window of 3)
    window = 3
    breakpoints = set()
    for i in range(len(similarities)):
        lo = max(0, i - window)
        hi = min(len(similarities), i + window + 1)
        local_avg = float(np.mean(similarities[lo:hi]))
        if similarities[i] < local_avg - BREAKPOINT_THRESHOLD:
            breakpoints.add(i + 1)  # cut AFTER sentence i

    # Merge sentences into chunks
    chunks   = []
    current  = []
    for i, sent in enumerate(sentences):
        current.append(sent)
        if i + 1 in breakpoints:
            chunks.append(" ".join(current))
            current = []
    if current:
        chunks.append(" ".join(current))

    # Enforce MAX_CHUNK_CHARS — split oversized chunks with fallback
    final = []
    fallback = RecursiveCharacterTextSplitter(
        chunk_size=MAX_CHUNK_CHARS,
        chunk_overlap=120,
        separators=["\n\n", "\n", r"(?<=\. )", " ", ""],
        is_separator_regex=True,
    )
    for chunk in chunks:
        if len(chunk) > MAX_CHUNK_CHARS:
            sub = fallback.split_text(chunk)
            final.extend(sub)
        else:
            final.append(chunk)

    return [c for c in final if len(c.strip()) >= MIN_CHUNK_CHARS]


# ── Helpers shared with original ──────────────────────────────────────────────
def _detect_file_type(doc: Document) -> str:
    source = doc.metadata.get("source", "")
    if "." in source:
        return "." + source.rsplit(".", 1)[-1].lower()
    return ""


def _clean_text(text: str, file_type: str) -> str:
    """Removes noise, fixes whitespace, and scrubs AI prompt-leaks from text."""
    # 1. Standard whitespace cleaning[cite: 13]
    text = re.sub(r"\n{3,}", "\n\n", text)
    
    # 2. Remove page numbers from PDFs/Word docs[cite: 13]
    if file_type in (".pdf", ".docx"):
        text = re.sub(r"(?m)^\s*-?\s*\d{1,4}\s*-?\s*$", "", text)
    
    # 3. Remove all-caps header lines[cite: 13]
    text = re.sub(r"(?m)^([A-Z][A-Z\s,.\-–]{2,58}[A-Z])$", "", text)

    # 🛡️ 4. THE PROMPT SCRUBBER: Removes AI instructions found inside the text
    # This prevents the "Rules" and "<think>" loops you were seeing!
    meta_patterns = [
        r"<\|im_start\|>", 
        r"<\|im_end\|>", 
        r"<think>", 
        r"</think>",
        r"system prompt",
        r"You are a precise assistant", 
        r"Answer using ONLY the provided context",
        r"Respond in the SAME language"
    ]
    for pattern in meta_patterns:
        text = re.compile(pattern, re.IGNORECASE).sub("", text)

    # 5. Final formatting cleanup[cite: 13]
    lines = [line.strip() for line in text.splitlines()]
    text  = "\n".join(lines)
    text  = text.replace("\t", " ")
    text  = re.sub(r" {2,}", " ", text)
    
    return text.strip()


def _get_fallback_splitter(file_type: str) -> RecursiveCharacterTextSplitter:
    profile = CHUNK_PROFILES.get(file_type, DEFAULT_PROFILE)
    if file_type in (".csv", ".xlsx"):
        separators = ["\n", " ", ""]
    elif file_type == ".md":
        separators = ["\n## ", "\n### ", "\n#### ", "\n\n", "\n", r"(?<=\. )", " ", ""]
    elif file_type == ".pptx":
        separators = ["\n\n", "\n", r"(?<=\. )", " ", ""]
    else:
        separators = ["\n\n", "\n", r"(?<=\. )", r"(?<=\? )", r"(?<=! )", " ", ""]
    return RecursiveCharacterTextSplitter(
        chunk_size=profile["chunk_size"],
        chunk_overlap=profile["chunk_overlap"],
        separators=separators,
        is_separator_regex=True,
    )


def _enrich_metadata(chunks: list[Document], source_doc: Document,
                     file_type: str, method: str) -> None:
    """Add metadata to each chunk including which split method was used."""
    total    = len(chunks)
    filename = (source_doc.metadata.get("source", "unknown")
                .replace("\\", "/").split("/")[-1])
    for i, chunk in enumerate(chunks):
        chunk.metadata["file_type"]    = file_type
        chunk.metadata["chunk_index"]  = i
        chunk.metadata["total_chunks"] = total
        chunk.metadata["doc_title"]    = filename
        chunk.metadata["split_method"] = method   # "semantic" or "fixed"


# ── Public API ────────────────────────────────────────────────────────────────
def split_docs(documents: list[Document],
               max_chunk_size=None,
               chunk_overlap=None) -> list[Document]:
    """
    Split documents into clean, enriched chunks.

    Uses semantic chunking (bge-m3 embeddings) for prose documents.
    Falls back to fixed-size splitting for CSV/XLSX and very short texts.

    Args:
        documents:      Raw LangChain Documents from load_documents()
        max_chunk_size: Override — forces fixed-size splitting if set
        chunk_overlap:  Override — forces fixed-size splitting if set

    Returns:
        List of cleaned, enriched Document chunks
    """
    logger.info("✂️  Splitting documents (semantic chunking)...")

    all_chunks   = []
    skipped_tiny = 0
    sem_count    = 0
    fix_count    = 0

    for doc in documents:
        file_type = _detect_file_type(doc)
        doc.page_content = _clean_text(doc.page_content, file_type)

        if not doc.page_content.strip():
            continue

        # Decide split method
        use_fixed = (
            file_type in FIXED_SPLIT_TYPES   # structured rows
            or max_chunk_size is not None     # manual override
            or chunk_overlap  is not None
            or len(doc.page_content) < 200    # too short for semantic analysis
        )

        if use_fixed:
            if max_chunk_size or chunk_overlap:
                profile = CHUNK_PROFILES.get(file_type, DEFAULT_PROFILE).copy()
                if max_chunk_size: profile["chunk_size"]    = max_chunk_size
                if chunk_overlap:  profile["chunk_overlap"] = chunk_overlap
                splitter = RecursiveCharacterTextSplitter(**profile)
            else:
                splitter = _get_fallback_splitter(file_type)
            raw_chunks = splitter.split_documents([doc])
            method = "fixed"
            fix_count += 1
        else:
            # Semantic split — returns plain strings, wrap in Documents
            texts      = _semantic_split(doc.page_content)
            raw_chunks = [
                Document(page_content=t, metadata=dict(doc.metadata))
                for t in texts
            ]
            method    = "semantic"
            sem_count += 1

        # Filter noise fragments
        valid = []
        for chunk in raw_chunks:
            if len(chunk.page_content.strip()) >= MIN_CHUNK_CHARS:
                valid.append(chunk)
            else:
                skipped_tiny += 1

        _enrich_metadata(valid, doc, file_type, method)
        all_chunks.extend(valid)

    # Summary
    logger.info(f"  ✅ {len(all_chunks)} chunks ready "
          f"({sem_count} semantic, {fix_count} fixed-split docs)")
    if skipped_tiny:
        logger.info(f"  🗑️  Discarded {skipped_tiny} fragments < {MIN_CHUNK_CHARS} chars")

    type_counts: dict[str, int] = {}
    for chunk in all_chunks:
        ft = chunk.metadata.get("file_type", "unknown")
        type_counts[ft] = type_counts.get(ft, 0) + 1
    for ft, count in sorted(type_counts.items()):
        logger.info(f"     {ft or 'unknown':8s} → {count} chunks")

    return all_chunks


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s | %(levelname)s | %(message)s',
    )
    try:
        from ..data.load_data import load_documents
    except ImportError:
        from load_data import load_documents

    raw_docs = load_documents("./data")
    chunks   = split_docs(raw_docs)

    if chunks:
        sample = chunks[0]
        method = sample.metadata.get("split_method", "?")
        logger.info(f"\nSample chunk [{method}] ({len(sample.page_content)} chars):")
        logger.info(sample.page_content[:400])
        logger.info(f"\nMetadata: {sample.metadata}")
