print("[DEBUG-1] 🚦 Python woke up! Raw dataset runner script started.")
import sys
import json
import traceback
import os
from pathlib import Path
print("[DEBUG-2] 📦 Standard libraries loaded.")

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Raw Evaluation Dataset Handler")
    parser.add_argument("--input", "-i", help="Input JSONL file", 
                        default="evaluation/eval_dataset.jsonl")
    parser.add_argument("--output", "-o", help="Output JSONL file",
                        default="evaluation/eval_dataset_raw.jsonl")
    
    args = parser.parse_args()
    
    print("[DEBUG-4] 🏃‍♂️ Entering main() function...")
    print("\n" + "="*70)
    print("📊 RAG EVALUATION DATASET HANDLER (Raw Dataset)")
    print("Processing raw dataset with messy questions as-is.")
    print("="*70)

    input_file = args.input
    output_file = args.output
    print(f"\n📂 Input:  {input_file}")
    print(f"📂 Output: {output_file}")

    try:
        print("[DEBUG-5] 📖 Loading raw dataset...")
        
        if not os.path.exists(input_file):
            print(f"❌ Input file not found: {input_file}")
            sys.exit(1)
        
        # Load raw data
        entries = []
        with open(input_file, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                try:
                    entry = json.loads(line.strip())
                    entries.append(entry)
                except json.JSONDecodeError as e:
                    print(f"⚠️  Skipping malformed line {line_num}: {e}")
                    continue
        
        print(f"[DEBUG-6] ✅ Loaded {len(entries)} entries from raw dataset")
        
        # Save raw data (no modifications)
        os.makedirs(os.path.dirname(output_file) or '.', exist_ok=True)
        with open(output_file, 'w', encoding='utf-8') as f:
            for entry in entries:
                f.write(json.dumps(entry, ensure_ascii=False) + '\n')
        
        print(f"📊 Processing complete!")
        print(f"   Total entries: {len(entries)}")
        print(f"   Output saved to: {output_file}")
        
        if entries:
            print(f"\n📝 Sample entry (raw - as-is):")
            print(f"   {json.dumps(entries[0], ensure_ascii=False, indent=2)}")

    except Exception as e:
        print("\n" + "!"*50)
        print("🚨 PROCESSING ERROR 🚨")
        print("!"*50)
        print(f"Error: {e}")
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    print("[DEBUG-0] 🏁 Hit __name__ == __main__ block")
    try:
        main()
    except Exception as e:
        print("\n" + "!"*50)
        print("🚨 RUNTIME ERROR IN MAIN 🚨")
        print("!"*50)
        traceback.print_exc()