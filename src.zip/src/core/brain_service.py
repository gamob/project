import os
import json
import hashlib
import shutil
from .config_service import ConfigManager
from .embed_store import (
    load_vector_store, create_vector_store, build_bm25_index, get_llama_embeddings,
    add_documents_incremental
)
from .retrieve import load_bm25, get_hybrid_docs, get_low_confidence_threshold
from ..data.load_data import load_documents, load_specific_files
from ..data.split_text import split_docs
from .generate import generate_search_queries

class Brain:
    """The central Service that manages the AI's memory and retrieval."""
    
    def __init__(self):
        self.faiss_path = ConfigManager.get("FAISS_INDEX_PATH", "faiss_index")
        self.bm25_path = ConfigManager.get("BM25_INDEX_PATH", "bm25_index.pkl")
        self.data_dir = ConfigManager.get("DATA_DIR", "data")
        self.state_path = "index_state.json"
        
        self.vector_store = None
        self.bm25_retriever = None
        self.bm25_data = None  # Store full BM25 data for incremental updates

    def _get_file_hash(self, filepath):
        """Generates an MD5 hash of a file's content."""
        hasher = hashlib.md5()
        with open(filepath, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hasher.update(chunk)
        return hasher.hexdigest()

    def is_built(self):
        """Checks if both indices exist on disk."""
        return os.path.exists(self.faiss_path) and os.path.exists(self.bm25_path)

    def load(self):
        """Loads indices into memory."""
        if not self.is_built():
            raise FileNotFoundError("Indices are missing. Need to build the brain first.")
        
        print("🧠 Waking up the brain indices...")
        self.vector_store = load_vector_store()
        
        # Load BM25 data (retriever + corpus for incremental updates)
        import pickle
        with open(self.bm25_path, "rb") as f:
            self.bm25_data = pickle.load(f)
        self.bm25_retriever = self.bm25_data["retriever"]
        
        print("✅ Brain is fully loaded and ready!")

    def build(self, chunks=None):
        """Builds a fresh brain. If chunks are None, it loads and splits them fresh."""
        
        # 1. Self-sufficient loading: If chunks aren't provided, fetch them!
        if chunks is None:
            print("🧠 No chunks provided, loading fresh from data folder...")
            raw_docs = load_documents("data") # Your data folder path
            chunks = split_docs(raw_docs)
        
        # 2. DELETE THE OLD STUFF
        if os.path.exists(self.faiss_path):
            shutil.rmtree(self.faiss_path)
        
        # 3. BUILD FRESH
        print(f"🔨 Building index with {len(chunks)} chunks...")
        self.vector_store = create_vector_store(chunks)
        self.bm25_retriever = build_bm25_index(chunks)
        
        # Store BM25 data for future incremental updates
        import pickle
        with open(self.bm25_path, "rb") as f:
            self.bm25_data = pickle.load(f)
        self.bm25_retriever = self.bm25_data["retriever"]

        print("✅ Brain rebuild complete!")

    def sync_indices(self):
        """Incremental Update: Only processes new/changed files (80-90% faster than rebuild)."""
        # 1. Load state
        state = {}
        if os.path.exists(self.state_path):
            with open(self.state_path, 'r') as f:
                state = json.load(f)

        # 2. Scan folder
        all_files = [os.path.join(dp, f) for dp, dn, filenames in os.walk(self.data_dir) for f in filenames]
        new_or_changed_files = []
        new_state = {}

        for file_path in all_files:
            current_hash = self._get_file_hash(file_path)
            new_state[file_path] = current_hash
            if state.get(file_path) != current_hash:
                new_or_changed_files.append(file_path)

        if not new_or_changed_files and self.is_built():
            print("✨ Brain is already up to date!")
            if not self.vector_store: self.load()
            return

        # 3. Process changes
        print(f"✨ Processing {len(new_or_changed_files)} changes in batches...")
        
        if not self.is_built():
            # If building from scratch, collect everything first
            all_new_chunks = []
            for file_path in new_or_changed_files:
                doc = load_specific_files([file_path])
                all_new_chunks.extend(split_docs(doc))
            self.build(all_new_chunks)
        else:
            # Use incremental updates (3-5x faster than full rebuild)
            if not self.vector_store:
                self.load()
            
            all_new_chunks = []
            for file_path in new_or_changed_files:
                print(f"  👉 Processing {os.path.basename(file_path)}...")
                doc = load_specific_files([file_path])
                chunks = split_docs(doc)
                all_new_chunks.extend(chunks)
            
            # Add all new chunks incrementally
            self.vector_store, self.bm25_data = add_documents_incremental(
                self.vector_store, self.bm25_data, all_new_chunks
            )
            self.bm25_retriever = self.bm25_data["retriever"]
            
        # 4. Save State
        with open(self.state_path, 'w', encoding='utf-8') as f:
            json.dump(new_state, f, ensure_ascii=False, indent=2)
        
        print("✅ Sync complete!")

    def search(self, query: str, extra_queries=None, k: int = 20):
        """Standardized interface for searching the documents."""
        if not self.vector_store or not self.bm25_retriever:
            raise ValueError("Brain is not loaded! Call brain.sync_indices() first.")

        # 1. Query rewriting — rewrite the raw query before searching.
        #    generate_search_queries() returns (best_rewrite, [alt1, alt2]).
        #    If extra_queries were passed in manually we skip the rewrite.
        if extra_queries is None:
            main_query, extra_queries = generate_search_queries(query)
        else:
            main_query = query

        # 2. Hybrid search across all query variants
        docs, _, _ = get_hybrid_docs(
            main_query,
            self.vector_store,
            self.bm25_retriever,
            k=k,
            rerank_limit=4,
            extra_queries=extra_queries
        )

        # 3. Calculate Confidence
        confidence_pct = 0
        low_confidence = True # Default to cautious
        
        if docs:
            # The reranker injected 'rerank_score' into the metadata during hybrid search
            top_score = docs[0].metadata.get("rerank_score", 0.0)
            
            # Convert raw score to a percentage (heuristic)
            # Adjust the multiplier (* 10) if your reranker outputs larger ranges
            confidence_pct = min(max(int(top_score * 10), 0), 100)
            
            # Check against the threshold defined in your config
            threshold = get_low_confidence_threshold()
            low_confidence = confidence_pct < threshold

        return docs, low_confidence, confidence_pct