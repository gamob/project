import bm25s
import pickle
import os
from sentence_transformers import CrossEncoder
from langchain_core.documents import Document
from .config_service import ConfigManager
import numpy as np

# --- STRICT OFFLINE ---
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"

# Lazy global variables
_reranker = None

def get_reranker_path():
    """Lazily fetches the reranker path."""
    rel_path = ConfigManager.get("RERANKER_PATH", "model/bge-reranker-v2-m3")
    return os.path.join(ConfigManager.PROJECT_ROOT, rel_path)

def get_low_confidence_threshold():
    """Lazily fetches the threshold from config."""
    return ConfigManager.get("LOW_CONFIDENCE_THRESHOLD", 50.0)

def get_reranker():
    """Lazily loads the reranker only when needed."""
    global _reranker
    if _reranker is None:
        path = get_reranker_path()
        print(f"🎯 Loading Reranker from: {path}")
        _reranker = CrossEncoder(path, device='cpu')
    return _reranker


def _normalize_vector_scores(scores, method='minmax'):
    """Normalize L2 distances to [0, 1] range (lower distance = higher relevance)."""
    scores = np.array(scores)
    if method == 'minmax':
        min_s, max_s = scores.min(), scores.max()
        if max_s > min_s:
            normalized = 1 - (scores - min_s) / (max_s - min_s)
        else:
            normalized = np.ones_like(scores)
    return normalized


def _normalize_bm25_scores(scores, method='minmax'):
    """Normalize BM25 scores to [0, 1] range."""
    scores = np.array(scores)
    if method == 'minmax':
        min_s, max_s = scores.min(), scores.max()
        if max_s > min_s:
            normalized = (scores - min_s) / (max_s - min_s)
        else:
            normalized = np.ones_like(scores)
    return normalized


def _fuse_hybrid_scores(vector_scores, bm25_scores, alpha=0.6):
    """Fuse normalized scores from both retrieval methods.
    
    Args:
        vector_scores: L2 distances from FAISS
        bm25_scores: Relevance scores from BM25
        alpha: Weight for vector search (0.6 = 60% vector, 40% BM25)
    
    Returns:
        Fused scores array
    """
    v_norm = _normalize_vector_scores(vector_scores)
    b_norm = _normalize_bm25_scores(bm25_scores)
    return alpha * v_norm + (1 - alpha) * b_norm


def rerank_batch(query, docs, reranker, top_k=5, batch_size=32):
    """Batch rerank documents efficiently (3-5x faster than single reranking).
    
    Args:
        query: User query
        docs: List of Document objects
        reranker: CrossEncoder model
        top_k: Number of top results to return
        batch_size: Batch size for reranking
    
    Returns:
        List of top-k reranked documents with scores in metadata
    """
    if not docs:
        return []
    
    doc_texts = [d.page_content for d in docs]
    
    # Batch predict (much faster than per-pair calls)
    all_scores = []
    for i in range(0, len(doc_texts), batch_size):
        batch_pairs = [[query, text] for text in doc_texts[i:i+batch_size]]
        batch_scores = reranker.predict(batch_pairs)
        
        # Handle both scalar and array returns from reranker
        if isinstance(batch_scores, np.ndarray):
            # Flatten if multi-dimensional, convert to list
            batch_scores = batch_scores.flatten().tolist()
        elif not isinstance(batch_scores, (list, tuple)):
            # Single score - wrap in list
            batch_scores = [batch_scores]
        
        all_scores.extend(batch_scores)
    
    # Sort and return top-k
    ranked = sorted(zip(all_scores, docs), key=lambda x: float(x[0]), reverse=True)
    
    final_docs = []
    for score, doc in ranked[:top_k]:
        # Safely convert score to float, handling numpy types
        try:
            score_float = float(score)
        except (ValueError, TypeError):
            score_float = 0.0
        
        doc.metadata["rerank_score"] = score_float
        final_docs.append(doc)
    
    return final_docs


def get_dynamic_rerank_limit(top_score: float, base_limit: int = 5) -> int:
    """Adaptively determine rerank limit based on confidence of top result.
    
    High confidence = fewer results needed. Low confidence = cast wider net.
    """
    if top_score > 0.85:
        return max(3, base_limit // 2)
    elif top_score > 0.70:
        return base_limit
    else:
        return base_limit * 2

def load_bm25(path):
    """Loads the BM25 index and re-syncs the corpus."""
    with open(path, "rb") as f:
        data = pickle.load(f)
    
    retriever = data["retriever"]
    retriever.corpus = data["corpus"]
    return retriever

from langchain_core.documents import Document

def search_single_query(query, db, bm25_retriever, k=3):
    # 1. Vector Search
    docs_with_scores = db.similarity_search_with_score(query, k=k)
    
    # 2. BM25 Search
    query_tokens = bm25s.tokenize([query])
    bm25_results = bm25_retriever.retrieve(query_tokens, k=k)
    
    docs = []
    min_l2 = float('inf')
    
    # Process Vector Results
    for doc, score in docs_with_scores:
        docs.append(doc)
        min_l2 = min(min_l2, score)
        
    # Process BM25 Results with explicit type enforcement
    # We check if documents exist and iterate safely
    if bm25_results.documents is not None and len(bm25_results.documents) > 0:
        # Safely extract items - handle both list and numpy array cases
        try:
            raw_items = bm25_results.documents[0]
            # If it's a numpy array, flatten it first
            if isinstance(raw_items, np.ndarray):
                raw_items = raw_items.flatten().tolist()
            elif not isinstance(raw_items, (list, tuple)):
                raw_items = list(raw_items)
        except (IndexError, TypeError):
            raw_items = []
        
        for item in raw_items:
            try:
                # CASE 1: Already a valid Document object
                if isinstance(item, Document):
                    docs.append(item)
                    
                # CASE 2: It's just a raw string (common with BM25)
                elif isinstance(item, str):
                    docs.append(Document(
                        page_content=item, 
                        metadata={"source": "bm25_search", "rerank_score": 0.0}
                    ))
                
                # CASE 3: It has 'page_content' but might not be a Document instance
                elif hasattr(item, "page_content"):
                    if not hasattr(item, "metadata"):
                        item.metadata = {"source": "bm25_search", "rerank_score": 0.0}
                    docs.append(item)
                
                # CASE 4: Convert numpy/numeric types to strings (safely)
                elif isinstance(item, (np.integer, np.floating)):
                    docs.append(Document(
                        page_content=str(item.item() if hasattr(item, 'item') else item),
                        metadata={"source": "bm25_search", "rerank_score": 0.0}
                    ))
                
                elif isinstance(item, (int, float)):
                    docs.append(Document(
                        page_content=str(item),
                        metadata={"source": "bm25_search", "rerank_score": 0.0}
                    ))
                
                # CASE 5: Try to handle as bytes or other iterables
                elif isinstance(item, (bytes, bytearray)):
                    docs.append(Document(
                        page_content=item.decode('utf-8', errors='ignore'),
                        metadata={"source": "bm25_search", "rerank_score": 0.0}
                    ))
                
                # CASE 6: Weird stuff (like a dict or list that shouldn't be here)
                else:
                    # Try to convert to string as last resort
                    try:
                        page_content = str(item)
                        if page_content and page_content != str(type(item)):
                            docs.append(Document(
                                page_content=page_content,
                                metadata={"source": "bm25_search", "rerank_score": 0.0}
                            ))
                    except Exception:
                        pass  # Skip items that can't be converted
                        
            except Exception as e:
                # Silently skip problematic items
                pass
            
    return docs, min_l2, len(docs)

def get_hybrid_docs(query, db, bm25_retriever, k=15, rerank_limit=5, extra_queries=None):
    # Use k=15 (or 20) to get a wide variety of matches
    all_queries = [query] + (extra_queries or [])
    all_docs = []

    for q in all_queries:
        docs, _, _ = search_single_query(q, db, bm25_retriever, k=k)
        all_docs.extend(docs)

    # Deduplicate
    unique_docs = list({doc.page_content: doc for doc in all_docs}.values())

    # Batch rerank (3-5x faster than sequential reranking)
    if unique_docs:
        final_docs = rerank_batch(query, unique_docs, get_reranker(), 
                                  top_k=rerank_limit, batch_size=32)
        return final_docs, 0, 0
    
    return [], 0, 0