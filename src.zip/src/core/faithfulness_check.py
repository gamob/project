"""
faithfulness_check.py — Evaluate faithfulness of RAG-generated answers.

Measures whether the generated answer is grounded in retrieved documents:
1. Token overlap analysis (basic check)
2. Semantic similarity of claims to evidence
3. Factual consistency scoring
4. Hallucination detection

Scores: 0.0-1.0 (1.0 = fully faithful, 0.0 = completely hallucinated)
"""

from typing import List, Dict, Tuple, Optional
import re
from langchain_core.documents import Document
from sentence_transformers import CrossEncoder
import numpy as np


class FaithfulnessChecker:
    """Evaluates faithfulness of generated answers against retrieved documents."""
    
    def __init__(self, reranker=None):
        """
        Initialize faithfulness checker.
        
        Args:
            reranker: Optional CrossEncoder for semantic similarity scoring
        """
        self.reranker = reranker  # Can be loaded lazily if needed
    
    def extract_claims(self, text: str) -> List[str]:
        """
        Extract factual claims from text.
        
        Simple heuristic: Split on periods and keep sentences with key entities.
        """
        sentences = re.split(r'[.!?]+', text)
        claims = []
        
        for sent in sentences:
            sent = sent.strip()
            if len(sent) > 10 and len(sent.split()) >= 4:  # Minimum length for a claim
                claims.append(sent)
        
        return claims
    
    def extract_key_entities(self, text: str) -> List[str]:
        """
        Extract key entities (names, numbers, specific terms).
        
        Simple heuristic: Words that are capitalized or quoted.
        """
        # Find capitalized words (potential entities)
        entities = re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', text)
        
        # Find quoted phrases
        quoted = re.findall(r'"([^"]+)"', text)
        
        # Find numbers/percentages
        numbers = re.findall(r'\d+(?:%|[,\d]*)?', text)
        
        return list(set(entities + quoted + numbers))
    
    def token_overlap_score(self, answer: str, documents: List[Document]) -> float:
        """
        Calculate token overlap between answer and documents.
        
        Simple metric: What fraction of answer tokens appear in documents?
        """
        if not documents or not answer:
            return 0.0
        
        answer_tokens = set(answer.lower().split())
        doc_text = " ".join([d.page_content.lower() for d in documents])
        doc_tokens = set(doc_text.split())
        
        # Remove common stop words for cleaner comparison
        stop_words = {"the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for", "of"}
        answer_tokens -= stop_words
        
        if not answer_tokens:
            return 0.5  # If only stop words, uncertain
        
        overlap = len(answer_tokens & doc_tokens)
        coverage = overlap / len(answer_tokens)
        
        return min(coverage, 1.0)
    
    def semantic_consistency_score(self, answer: str, documents: List[Document]) -> float:
        """
        Score semantic consistency between answer and documents using embeddings.
        
        Requires reranker to be initialized.
        """
        if not self.reranker or not documents:
            return 0.5  # Neutral if can't evaluate
        
        doc_text = " ".join([d.page_content[:500] for d in documents[:3]])  # Top 3 docs
        
        try:
            # Score how well the answer matches the document content
            pairs = [[doc_text, answer]]
            scores = self.reranker.predict(pairs)
            
            # Normalize score to [0, 1]
            # CrossEncoder outputs are typically in range [-inf, +inf]
            # Apply sigmoid to normalize
            score = float(scores[0]) if isinstance(scores, (list, np.ndarray)) else float(scores)
            consistency = 1.0 / (1.0 + np.exp(-score))  # Sigmoid normalization
            
            return min(max(consistency, 0.0), 1.0)
        except Exception:
            return 0.5  # Return neutral on error
    
    def entity_grounding_score(self, answer: str, documents: List[Document]) -> float:
        """
        Check if specific entities in answer are grounded in documents.
        
        Returns: Fraction of entities that appear in documents
        """
        if not documents:
            return 0.0
        
        answer_entities = self.extract_key_entities(answer)
        if not answer_entities:
            return 1.0  # No specific claims to verify
        
        doc_text = " ".join([d.page_content for d in documents])
        
        grounded = 0
        for entity in answer_entities:
            if entity.lower() in doc_text.lower():
                grounded += 1
        
        grounding = grounded / len(answer_entities)
        return grounding
    
    def contradiction_detection(self, answer: str, documents: List[Document]) -> float:
        """
        Simple contradiction detection using negation markers.
        
        Returns: 1.0 if no contradictions, lower scores indicate potential issues
        """
        negation_markers = [
            ("not ", " "),
            ("no ", " "),
            ("never ", " "),
            ("without ", " "),
            ("isn't", "is"),
            ("doesn't", "does"),
            ("won't", "will"),
            ("can't", "can"),
        ]
        
        doc_text = " ".join([d.page_content for d in documents]).lower()
        answer_lower = answer.lower()
        
        contradiction_count = 0
        for neg, pos in negation_markers:
            if neg in answer_lower:
                # Check if document contradicts this
                claim_start = answer_lower.find(neg) + len(neg)
                claim_end = min(claim_start + 100, len(answer_lower))
                claim = answer_lower[claim_start:claim_end]
                
                # Simple heuristic: if positive form appears in docs, potential contradiction
                if pos in doc_text and claim.split()[0] in doc_text:
                    contradiction_count += 1
        
        if contradiction_count > 0:
            return 0.7  # Some contradictions found
        
        return 1.0
    
    def compute_faithfulness_score(self, answer: str, documents: List[Document],
                                   weights: Optional[Dict[str, float]] = None) -> Dict:
        """
        Compute comprehensive faithfulness score.
        
        Args:
            answer: Generated answer to evaluate
            documents: Retrieved source documents
            weights: Custom weights for different metrics (default: equal)
        
        Returns:
            Dict with:
            - overall_score: 0.0-1.0 (1.0 = fully faithful)
            - component_scores: Breakdown of individual metrics
            - is_faithful: Boolean (True if score > 0.7)
            - concerns: List of flagged issues
        """
        if not weights:
            weights = {
                "token_overlap": 0.25,
                "semantic_consistency": 0.30,
                "entity_grounding": 0.25,
                "contradiction": 0.20,
            }

        if self.reranker is None:
            sem_weight = weights.pop("semantic_consistency", 0.0)
            total_weight = sum(weights.values())
            if total_weight > 0 and sem_weight > 0:
                for key in weights:
                    weights[key] = weights[key] + (weights[key] / total_weight) * sem_weight

        # Calculate individual scores
        token_score = self.token_overlap_score(answer, documents)
        semantic_score = self.semantic_consistency_score(answer, documents)
        entity_score = self.entity_grounding_score(answer, documents)
        contradiction_score = self.contradiction_detection(answer, documents)
        
        # Weighted average
        overall_score = (
            weights.get("token_overlap", 0.25) * token_score +
            weights.get("semantic_consistency", 0.0) * semantic_score +
            weights.get("entity_grounding", 0.25) * entity_score +
            weights.get("contradiction", 0.20) * contradiction_score
        )
        
        # Flag concerns
        concerns = []
        if token_score < 0.3:
            concerns.append("Low token overlap with source documents")
        if semantic_score < 0.4:
            concerns.append("Semantic mismatch with document content")
        if entity_score < 0.5:
            concerns.append("Key entities not grounded in documents")
        if contradiction_score < 0.9:
            concerns.append("Potential contradictions with documents")
        
        return {
            "overall_score": float(overall_score),
            "is_faithful": overall_score > 0.7,
            "confidence_level": self._score_to_confidence(overall_score),
            "component_scores": {
                "token_overlap": float(token_score),
                "semantic_consistency": float(semantic_score),
                "entity_grounding": float(entity_score),
                "contradiction": float(contradiction_score),
            },
            "concerns": concerns,
            "evidence_count": len(documents),
        }
    
    @staticmethod
    def _score_to_confidence(score: float) -> str:
        """Convert numeric score to human-readable confidence level."""
        if score >= 0.9:
            return "Very High"
        elif score >= 0.75:
            return "High"
        elif score >= 0.6:
            return "Moderate"
        elif score >= 0.4:
            return "Low"
        else:
            return "Very Low"


def evaluate_answer_faithfulness(answer: str, 
                                documents: List[Document],
                                reranker=None) -> Dict:
    """
    Convenience function to evaluate answer faithfulness.
    
    Args:
        answer: Generated answer
        documents: Retrieved documents
        reranker: Optional CrossEncoder for semantic scoring
    
    Returns:
        Faithfulness evaluation report
    """
    checker = FaithfulnessChecker(reranker)
    return checker.compute_faithfulness_score(answer, documents)
