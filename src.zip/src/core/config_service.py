import json
import os

class ConfigManager:
    _settings = {}
    _tried_loading = False  # <--- NEW: Memory to prevent retrying forever
    PROJECT_ROOT = None

    @classmethod
    def _load_once(cls):
        """Internal helper to load the config only once."""
        if cls._tried_loading: return # Stop if we already tried
        
        cls._tried_loading = True # Mark as tried
        
        # 1. Find where this file is
        src_dir = os.path.dirname(os.path.abspath(__file__))
        
        # 2. Define the Root (This looks at the folder ABOVE your current folder)
        cls.PROJECT_ROOT = os.path.dirname(src_dir)
        
        # 3. Look for config.json
        config_path = os.path.join(cls.PROJECT_ROOT, "config.json")
        
        if os.path.exists(config_path):
            with open(config_path, "r", encoding="utf-8") as f: # Add the encoding!
                cls._settings = json.load(f)

    @classmethod
    def get(cls, key, default=None):
        """Safe getter that triggers a load if needed."""
        cls._load_once() 
        return cls._settings.get(key, default)

# Trigger the load immediately when imported
ConfigManager._load_once()