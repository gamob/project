import os
import pickle
import bm25s
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from .config_service import ConfigManager

# --- STRICT OFFLINE ---
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"

def get_path(key, default_rel_path):
    """Safely builds an absolute path from the project root."""
    # Fetch relative path from config
    rel_path = ConfigManager.get(key, default_rel_path)
    # Join with the project root defined in ConfigManager
    return os.path.join(ConfigManager.PROJECT_ROOT, rel_path)

def get_llama_embeddings():
    """Initializes embeddings using the path from config."""
    model_path = get_path("MODEL_PATH", "model/bge-m3")
    return HuggingFaceEmbeddings(
        model_name=model_path,
        model_kwargs={'device': 'cpu'}, 
        encode_kwargs={'normalize_embeddings': True}
    )

def create_vector_store(chunks):
    """Builds and saves the FAISS vector store."""
    embeddings = get_llama_embeddings()
    path = get_path("FAISS_INDEX_PATH", "faiss_index")
    
    print(f"🧠 Building Vector Store with {len(chunks)} chunks...")
    vector_store = FAISS.from_documents(chunks, embeddings)
    vector_store.save_local(path)
    print(f"✅ FAISS index saved to '{path}'")
    return vector_store

def load_vector_store():
    """Loads the saved FAISS index from disk."""
    embeddings = get_llama_embeddings()
    path = get_path("FAISS_INDEX_PATH", "faiss_index")
    
    return FAISS.load_local(
        path,
        embeddings,
        allow_dangerous_deserialization=True
    )

def build_bm25_index(chunks):
    """Builds and saves the BM25 index WITH the corpus texts included."""
    path = get_path("BM25_INDEX_PATH", "bm25_index.pkl")
    
    corpus_texts = [chunk.page_content for chunk in chunks]
    tokenized_corpus = bm25s.tokenize(corpus_texts)
    
    retriever = bm25s.BM25()
    retriever.index(tokenized_corpus)
    
    data_to_save = {
        "retriever": retriever,
        "corpus": corpus_texts
    }
    
    with open(path, "wb") as f:
        pickle.dump(data_to_save, f)
        
    print(f"✅ BM25 index saved to '{path}' with corpus included.")
    return retriever


def add_documents_incremental(vector_store, bm25_data, new_chunks):
    """Add new documents to existing indices without full rebuild (80-90% faster).
    
    Args:
        vector_store: Existing FAISS vector store
        bm25_data: Dict with 'retriever' and 'corpus' keys
        new_chunks: List of new Document chunks to add
    
    Returns:
        Updated vector_store and bm25_data
    """
    if not new_chunks:
        return vector_store, bm25_data
    
    embeddings = get_llama_embeddings()
    
    # Add to FAISS (much faster than rebuild)
    print(f"📝 Adding {len(new_chunks)} chunks to existing indices...")
    vector_store.add_documents(new_chunks)
    
    # Add to BM25
    new_corpus_texts = [chunk.page_content for chunk in new_chunks]
    new_tokenized = bm25s.tokenize(new_corpus_texts)
    bm25_data["retriever"].index(new_tokenized)
    bm25_data["corpus"].extend(new_corpus_texts)
    
    # Save updated indices
    faiss_path = get_path("FAISS_INDEX_PATH", "faiss_index")
    bm25_path = get_path("BM25_INDEX_PATH", "bm25_index.pkl")
    
    vector_store.save_local(faiss_path)
    with open(bm25_path, "wb") as f:
        pickle.dump(bm25_data, f)
    
    print(f"✅ Indices updated incrementally ({len(new_chunks)} new documents)")
    return vector_store, bm25_data