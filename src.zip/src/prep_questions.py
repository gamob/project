from src.eval.prep_questions import main

if __name__ == "__main__":
    main()
