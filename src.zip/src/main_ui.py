from src.ui.main_ui import main

if __name__ == "__main__":
    main()
