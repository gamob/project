from src.eval.merge_eval_datasets import main

if __name__ == "__main__":
    main()
