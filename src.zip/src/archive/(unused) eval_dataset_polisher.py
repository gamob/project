print("[DEBUG-A] 📄 Inside eval_dataset_polisher.py")
import json
import re
import time
import logging
from typing import Dict, List, Tuple, Optional
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

print("[DEBUG-B] 📄 Trying to import langchain_ollama...")
try:
    from langchain_ollama import OllamaLLM
    print("[DEBUG-C] ✅ langchain_ollama imported!")
except ImportError as e:
    print(f"🚨 [DEBUG] ERROR importing langchain_ollama: {e}")

OLLAMA_BASE_URL = "http://localhost:11434"

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger = logging.getLogger(__name__)

class EvalDatasetPolisher:
    def __init__(self, model_name: str = "qwen27b", temperature: float = 0.3,
                 max_retries: int = 3, retry_delay: float = 1.0,
                 max_workers: int = 2, base_url: str = None):
        print("[DEBUG-D] 🔧 Initializing EvalDatasetPolisher class...")

        self.config = {
            'model_name': model_name,
            'temperature': temperature,
            'max_retries': max_retries,
            'retry_delay': retry_delay,
            'max_workers': max_workers,
            'base_url': base_url or OLLAMA_BASE_URL
        }

        self.vietnamese_keywords = {
            'ngưỡng', 'khoảng', 'tối thiểu', 'tối đa', 'hệ thống', 'quá trình',
            'bước', 'phát hiện', 'điểm', 'cải tiến', 'giảm', 'tăng', 'khoảnh khắc',
            'vàng', 'bảo hiểm', 'nhân công', 'mô hình', 'tham số', 'gạch nợ',
            'hoá đơn', 'dịch vụ', 'giao diện', 'CMS', 'khai báo', 'quản lý',
        }

        print("[DEBUG-E] 🔌 Setting up OllamaLLM...")
        try:
            self.llm = OllamaLLM(
                model=self.config['model_name'],
                base_url=self.config['base_url'],
                temperature=self.config['temperature'],
                num_ctx=4096,       # Keeps the context window tight for speed

                # 🏎️ HARDWARE OPTIMIZATION
                num_thread=64,      # Uses 64 of your 96 cores
                keep_alive=-1,    # Keeps model in VRAM

                # 🧠 BEHAVIOR CONTROL
                repeat_penalty=1.2, # Stops repetition
                num_predict=512,    # Allow flexible response length

                # 🛡️ STOP TOKENS — do NOT stop on <think> for text-generation tasks.
                # Qwen outputs <think>...</think> first; stopping there returns ''.
                # The fix_with_llm() caller uses regex to extract content regardless.
                stop=["<|im_start|>", "<|im_end|>"],
                timeout=60,    # Timeout for GPU server
            )
            print("[DEBUG-F] ✅ OllamaLLM configuration loaded!")
        except Exception as e:
            logger.error(f"Failed to initialize LLM: {e}")
            raise RuntimeError(f"LLM initialization failed: {e}")

        # Initialize thread pool for parallel processing
        self.executor = ThreadPoolExecutor(max_workers=self.config['max_workers'])
        logger.info(f"EvalDatasetPolisher initialized with model: {model_name}")

        # Validate LLM connection
        self._validate_llm_connection()

    def _validate_llm_connection(self):
        """Validate LLM connection with a simple test."""
        try:
            logger.info("Testing LLM connection...")
            test_prompt = "Say 'OK' if you can understand this message."
            response = self.llm.invoke(test_prompt)
            if response and len(response.strip()) > 0:
                logger.info("✅ LLM connection validated")
            else:
                raise RuntimeError("LLM returned empty response")
        except Exception as e:
            logger.error(f"LLM connection test failed: {e}")
            raise RuntimeError(f"Cannot connect to LLM: {e}")
    
    def detect_circular_question(self, question: str, answer: str) -> Tuple[bool, str]:
        """Detect if a question is circular (answer just translates question)."""
        q_clean = question.lower().strip('?.,')
        a_clean = answer.lower().strip('?.,')
        
        # Check: Answer has very few unique words not in question
        q_words = set(re.findall(r'\b\w+\b', q_clean))
        a_words = set(re.findall(r'\b\w+\b', a_clean))
        
        unique_in_answer = len(a_words - q_words)
        if unique_in_answer <= 2 and len(a_words) < 6:
            return True, "Circular: answer repeats question structure"
        
        # Check: Answer is vague/incomplete
        if len(a_clean.split()) <= 3 and not any(char.isdigit() for char in a_clean):
            if a_clean not in ['yes', 'no', 'true', 'false', '1', '0']:
                return True, "Brief: answer lacks specificity"
        
        return False, ""
    
    def detect_mixed_language(self, text: str) -> Tuple[bool, str]:
        """Detect if text is mixed language."""
        vietnamese_found = any(word in text.lower() for word in self.vietnamese_keywords)
        has_english = bool(re.search(r'[a-z]{3,}', text, re.IGNORECASE))
        
        return vietnamese_found and has_english, "mixed"
    
    def fix_with_llm(self, question: str, answer: str, issue_type: str) -> Tuple[str, str]:
        """Use Qwen 27B to intelligently fix the issue with retry logic."""

        if issue_type == "circular":
            prompt = f"""/no_think
Your task is to rewrite an evaluation QA pair that is currently circular (the answer just repeats the question).

Original Question: {question}
Original Answer: {answer}

Rewrite the question to be more specific and contextual, and provide a comprehensive, descriptive answer. The answer should be 2-3 sentences.

Format your response as:
QUESTION: [rewritten question]
ANSWER: [comprehensive answer]"""

        elif issue_type == "mixed_language":
            prompt = f"""/no_think
Fix this mixed-language evaluation entry to be consistently in proper English.

Question: {question}
Answer: {answer}

Rewrite both to professional English, translating any Vietnamese terms to English equivalents.

Format your response as:
QUESTION: [English question]
ANSWER: [English answer]"""

        elif issue_type == "brief_answer":
            prompt = f"""/no_think
Expand this brief answer into a comprehensive, descriptive response (2-3 sentences).

Question: {question}
Current Answer: {answer}

Provide a full, contextual answer that explains the concept properly for evaluation metrics.

Format your response as:
ANSWER: [expanded answer]"""

        else:
            return question, answer

        # Retry logic with exponential backoff
        for attempt in range(self.config['max_retries']):
            try:
                logger.debug(f"LLM call attempt {attempt + 1}/{self.config['max_retries']} for {issue_type}")
                raw = self.llm.invoke(prompt).strip()
                # Strip Qwen's <think>...</think> reasoning block before parsing
                result = re.sub(r'<think>.*?</think>', '', raw, flags=re.DOTALL).strip()

                if issue_type == "brief_answer":
                    # Just extract answer
                    match = re.search(r'ANSWER:\s*(.+?)(?:\n|$)', result, re.DOTALL)
                    if match:
                        return question, match.group(1).strip()
                    return question, answer
                else:
                    # Extract both question and answer
                    q_match = re.search(r'QUESTION:\s*(.+?)(?:\nANSWER:|$)', result, re.DOTALL)
                    a_match = re.search(r'ANSWER:\s*(.+?)$', result, re.DOTALL)

                    new_q = q_match.group(1).strip() if q_match else question
                    new_a = a_match.group(1).strip() if a_match else answer

                    return new_q, new_a

            except Exception as e:
                logger.warning(f"LLM error on attempt {attempt + 1}: {e}")
                if attempt < self.config['max_retries'] - 1:
                    time.sleep(self.config['retry_delay'] * (2 ** attempt))  # Exponential backoff
                else:
                    logger.error(f"All LLM retry attempts failed for {issue_type}")
                    return question, answer

        return question, answer
    
    def process_entry(self, entry: Dict) -> Dict:
        """Process a single evaluation entry."""
        question = str(entry.get('question', '')).strip()
        answer = str(entry.get('answer', '')).strip()
        
        improvements = []
        processed = entry.copy()
        
        # Check for circular question
        is_circular, reason = self.detect_circular_question(question, answer)
        if is_circular:
            improvements.append(f"DETECTED: {reason}")
            new_q, new_a = self.fix_with_llm(question, answer, "circular")
            if new_q != question or new_a != answer:
                processed['question'] = new_q
                processed['answer'] = new_a
                improvements.append("FIXED: LLM rewrote with context")
        
        # Check for mixed language (in both question and answer)
        is_mixed_q, _ = self.detect_mixed_language(question)
        is_mixed_a, _ = self.detect_mixed_language(answer)
        
        if is_mixed_q or is_mixed_a:
            improvements.append("DETECTED: Mixed language")
            new_q, new_a = self.fix_with_llm(processed['question'], processed['answer'], "mixed_language")
            processed['question'] = new_q
            processed['answer'] = new_a
            improvements.append("FIXED: Converted to clean English")
        
        # Check if answer is still brief (even after circular fix)
        if len(str(processed.get('answer', '')).split()) <= 4:
            improvements.append("DETECTED: Brief answer")
            _, expanded_a = self.fix_with_llm(processed['question'], processed['answer'], "brief_answer")
            processed['answer'] = expanded_a
            improvements.append("FIXED: Expanded to full sentence")
        
        # Store improvement log
        if improvements:
            processed['_improvements'] = improvements
            processed['_quality_score'] = 1.0 - (len([i for i in improvements if i.startswith('DETECTED')]) * 0.1)
        else:
            processed['_quality_score'] = 1.0
        
        return processed
    
    def process_file(self, input_path: str, output_path: str, verbose: bool = True,
                    batch_size: int = 10) -> Dict:
        """Process entire JSONL file and output polished version with parallel processing."""
        input_file = Path(input_path)
        output_file = Path(output_path)

        stats = {
            'total': 0,
            'improved': 0,
            'circular_fixed': 0,
            'language_fixed': 0,
            'answers_expanded': 0,
            'high_quality': 0,
            'errors': 0,
            'processing_time': 0,
        }

        start_time = time.time()

        # Read input file
        try:
            if input_file.suffix == '.jsonl':
                with open(input_file, 'r', encoding='utf-8') as f:
                    entries = [json.loads(line) for line in f if line.strip()]
            else:
                with open(input_file, 'r', encoding='utf-8') as f:
                    entries = json.load(f)
        except Exception as e:
            logger.error(f"Failed to read input file {input_path}: {e}")
            raise

        logger.info(f"🔄 Processing {len(entries)} evaluation entries...")
        if verbose:
            print(f"🔄 Processing {len(entries)} evaluation entries...")

        processed_entries = []

        # Process in batches to manage memory and provide progress updates
        for i in range(0, len(entries), batch_size):
            batch = entries[i:i + batch_size]
            batch_start_time = time.time()

            if verbose and i > 0:
                print(f"  📦 Processing batch {i//batch_size + 1}/{(len(entries) + batch_size - 1)//batch_size}...")

            # Submit batch to thread pool
            futures = [self.executor.submit(self.process_entry, entry) for entry in batch]

            # Collect results
            for future in as_completed(futures):
                try:
                    processed = future.result()
                    processed_entries.append(processed)

                    stats['total'] += 1
                    if '_improvements' in processed:
                        stats['improved'] += 1

                        # Track specific improvements
                        improvements_str = ' '.join(processed['_improvements'])
                        if 'Circular' in improvements_str or 'circular' in improvements_str:
                            stats['circular_fixed'] += 1
                        if 'Mixed language' in improvements_str or 'language' in improvements_str.lower():
                            stats['language_fixed'] += 1
                        if 'Expanded' in improvements_str or 'expanded' in improvements_str.lower():
                            stats['answers_expanded'] += 1

                    if processed.get('_quality_score', 0) == 1.0:
                        stats['high_quality'] += 1

                except Exception as e:
                    logger.error(f"Error processing entry: {e}")
                    stats['errors'] += 1
                    stats['total'] += 1

            batch_time = time.time() - batch_start_time
            if verbose:
                processed_in_batch = len(batch)
                print(f"  ✓ Batch {i//batch_size + 1} completed ({processed_in_batch} entries, {batch_time:.1f}s)")

        # Write output file
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                for entry in processed_entries:
                    f.write(json.dumps(entry, ensure_ascii=False) + '\n')
        except Exception as e:
            logger.error(f"Failed to write output file {output_path}: {e}")
            raise

        stats['processing_time'] = time.time() - start_time
        logger.info(f"✅ Polished dataset saved to: {output_file}")
        if verbose:
            print(f"✅ Polished dataset saved to: {output_file}")

        return stats, processed_entries

    def cleanup(self):
        """Clean up resources."""
        if hasattr(self, 'executor'):
            self.executor.shutdown(wait=True)
            logger.info("Thread pool shut down")

    def __del__(self):
        """Destructor to ensure cleanup."""
        self.cleanup()


def print_report(stats: Dict):
    """Print terminal-friendly report with timing and error information."""
    print("\n" + "="*70)
    print("📊 RAG EVALUATION DATASET POLISH REPORT")
    print("="*70)
    print(f"Total Entries:           {stats['total']}")
    print(f"Improved Entries:        {stats['improved']} ({stats['improved']/max(stats['total'],1)*100:.1f}%)")
    print(f"High Quality (no fixes): {stats['high_quality']} ({stats['high_quality']/max(stats['total'],1)*100:.1f}%)")

    if 'errors' in stats and stats['errors'] > 0:
        print(f"Errors Encountered:      {stats['errors']} ({stats['errors']/max(stats['total'],1)*100:.1f}%)")

    if 'processing_time' in stats:
        print(f"Processing Time:         {stats['processing_time']:.1f}s")
        if stats['total'] > 0:
            print(f"Average Time/Entry:      {stats['processing_time']/stats['total']:.2f}s")

    print(f"\nFixes Applied:")
    print(f"  • Circular Questions:   {stats['circular_fixed']}")
    print(f"  • Language Issues:      {stats['language_fixed']}")
    print(f"  • Answers Expanded:     {stats['answers_expanded']}")
    print("="*70 + "\n")


def print_sample_improvements(entries: List[Dict], num_samples: int = 3):
    """Print sample improvements to terminal."""
    improved = [e for e in entries if '_improvements' in e]
    
    if not improved:
        print("✅ No improvements needed!")
        return
    
    print("\n" + "="*70)
    print("📝 SAMPLE IMPROVEMENTS")
    print("="*70)
    
    for i, entry in enumerate(improved[:num_samples], 1):
        print(f"\n{i}. Improvements Applied:")
        for imp in entry.get('_improvements', []):
            print(f"   • {imp}")
        print(f"\n   Question: {entry.get('question', '')[:70]}...")
        print(f"   Answer:   {entry.get('answer', '')[:70]}...")

# (Note: I removed the duplicate __main__ block that was originally stuck at the bottom here!)