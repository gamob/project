import os
import re
import unicodedata
from langchain_community.document_loaders import (
    PyPDFLoader,
    TextLoader,
    DirectoryLoader,
    Docx2txtLoader,
    CSVLoader,
    UnstructuredPowerPointLoader,
    UnstructuredExcelLoader,
)
from ..core.config_service import ConfigManager

# Map file extensions to their LangChain loader class
LOADERS = {
    ".pdf":  PyPDFLoader,
    ".txt":  TextLoader,
    ".md":   TextLoader,                    # Markdown is plain text
    ".docx": Docx2txtLoader,               # Word documents
    ".pptx": UnstructuredPowerPointLoader, # PowerPoint slides
    ".xlsx": UnstructuredExcelLoader,      # Excel spreadsheets
    ".csv":  CSVLoader,                    # CSV files
}

def clean_text(text: str) -> str:
    """Removes noise, weird characters, and fixes whitespace."""
    # 1. Remove non-printable control characters
    text = re.sub(r'[\x00-\x1f\x7f]', '', text)
    
    # 2. Fix excessive whitespace (newlines/tabs to single space)
    text = re.sub(r'\s+', ' ', text).strip()
    
    # 3. (Optional) Remove common header/footer junk if you find it
    # You can add specific regexes here for your office docs!
    # text = re.sub(r'Confidential Page \d+ of \d+', '', text) 
    
    return text

def sanitize_filename(name):
    """Turns Vietnamese/special chars into ASCII-friendly names."""
    # Normalize unicode (decomposes accents)
    nfkd_form = unicodedata.normalize('NFKD', name)
    # Remove non-ascii characters
    ascii_name = nfkd_form.encode('ASCII', 'ignore').decode('ASCII')
    # Replace spaces and special chars with underscores
    clean_name = re.sub(r'[^a-zA-Z0-9.]', '_', ascii_name)
    # Clean up double underscores
    return re.sub(r'_+', '_', clean_name)

def sanitize_data_folder(directory_path):
    """Renames all files in the directory to be ASCII-safe."""
    files = os.listdir(directory_path)
    for filename in files:
        if filename.startswith('.'): continue # Skip hidden files
        
        new_name = sanitize_filename(filename)
        if new_name != filename:
            old_path = os.path.join(directory_path, filename)
            new_path = os.path.join(directory_path, new_name)
            
            # Prevent accidental overwrites if two files have similar names
            if not os.path.exists(new_path):
                os.rename(old_path, new_path)
                print(f"✨ Auto-renamed: {filename} -> {new_name}")
            else:
                print(f"⚠️ Collision skipped: {filename} (target {new_name} exists)")

def load_documents(directory_path):
    # 1. CLEAN FIRST!
    print("🧹 Cleaning data folder names...")
    sanitize_data_folder(directory_path)
    
    # 2. THEN LOAD
    docs = []
    failed = []

    for extension, loader_cls in LOADERS.items():
        # ... (Your existing loader loop) ...
        try:
            loader = DirectoryLoader(
                directory_path,
                glob=f"**/*{extension}",
                loader_cls=loader_cls,
                silent_errors=True
            )
            loaded = loader.load()
            
            # --- THE CLEANING MAGIC HAPPENS HERE ---
            for doc in loaded:
                doc.page_content = clean_text(doc.page_content)
            # ---------------------------------------

            if loaded:
                print(f"  ✅ Loaded and Cleaned {len(loaded)} pages from *{extension} files")
            docs.extend(loaded)
        except Exception as e:
            failed.append(f"{extension}: {e}")

    if failed:
        print(f"\n⚠️ Some file types failed to load:")
        for f in failed:
            print(f"  - {f}")

    print(f"\n📚 Total: {len(docs)} pages loaded from {directory_path}")
    return docs

if __name__ == "__main__":
    data_dir = ConfigManager.get("DEFAULT_DATA_DIR")
    my_docs = load_documents(data_dir)
    if my_docs:
        print(f"\nSample Content:\n{my_docs[0].page_content[:200]}...")

def load_specific_files(file_paths):
    """Loads only the files provided in the list."""
    docs = []
    for path in file_paths:
        ext = os.path.splitext(path)[1]
        loader_cls = LOADERS.get(ext)
        if loader_cls:
            try:
                loader = loader_cls(path)
                loaded = loader.load()
                docs.extend(loaded)
                print(f"  ✅ Loaded: {os.path.basename(path)}")
            except Exception as e:
                print(f"  ❌ Error loading {path}: {e}")
    return docs