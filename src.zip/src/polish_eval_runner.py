from src.eval.polish_eval_runner import main

if __name__ == "__main__":
    main()
