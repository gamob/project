from src.eval.generate_evals import main

if __name__ == "__main__":
    main()
